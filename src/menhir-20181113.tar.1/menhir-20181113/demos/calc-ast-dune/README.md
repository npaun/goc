This demo illustrates how to build abstract syntax trees.
It uses the new rule syntax.
