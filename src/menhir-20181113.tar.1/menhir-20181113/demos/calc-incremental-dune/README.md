This demo is identical to the `calc-incremental` demo
but uses dune instead of ocamlbuild.
